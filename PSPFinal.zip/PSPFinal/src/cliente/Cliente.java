package cliente;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import dao.CompraDAO;
import dao.ProductoDAO;
import entidades.Empleado;
import entidades.Producto;
import mensaje.Mail;
import mensaje.Mensaje;

public class Cliente {

	private static boolean conectado = false;
	private static Empleado user = null;
	private static Socket socket = null;
	private static OutputStream outputStream = null;
	private static ObjectOutputStream objectOutputStream = null;
	private static InputStream inputStream = null;
	private static ObjectInputStream objectInputStream = null;

	public static void main(String[] args) throws IOException, ClassNotFoundException {

		socket = new Socket("localhost", 8000);
		outputStream = socket.getOutputStream();
		objectOutputStream = new ObjectOutputStream(outputStream);
		inputStream = socket.getInputStream();
		objectInputStream = new ObjectInputStream(inputStream);

		System.out.println("Conectado!");

		while (!conectado)
			conectar();

		System.out.println(user.bienvenida());
		menu();
	}
	/**
	 * Pide y busca un usuario
	 * @throws IOException
	 */
	public static void conectar() throws IOException {

		String codigo = "";
		while (codigo.equals("")) {
			codigo = codigo();
		}
		objectOutputStream.writeObject(new Empleado(codigo));
		try {
			user = (Empleado) objectInputStream.readObject();
		} catch (Exception e) {
			System.err.println("Error al encontrar el usuario");
		}
		if (user != null) {
			conectado = true;
		} else {
			System.err.println("Usuario err�neo");
		}
	}
	/**
	 * Solicita al usuario su codigo de empleado
	 * @return
	 */
	public static String codigo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce tu n�mero de empleado");
		String codigo = sc.nextLine();

		try {
			Integer.valueOf(codigo);
		} catch (Exception e) {
			System.err.println("Debes introducir un codigo numerico");
			return "";
		}
		return codigo;

	}

	/**
	 * Men� principal de la aplicaci�n
	 * Pide al usuario elegir qu� des�a hacer y gestiona
	 * las acciones
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static void menu() throws IOException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Qu� deseas hacer, " + user.getNombre() + "?");
		System.out.println("1: Cobrar compra");
		System.out.println("2: Obtener caja del d�a");
		System.out.println("3: Salir");
		String eleccion = sc.nextLine();
		switch (eleccion) {
			case "1":
				objectOutputStream.writeObject(new Mensaje("Cobrar"));

				ArrayList<Producto> productos = new ArrayList<>();
				productos = ((ProductoDAO) objectInputStream.readObject()).getProductos();
				System.out.println();
				menu_compra(productos);
				menu();
				break;
			case "2":
				objectOutputStream.writeObject(new Mensaje("Caja"));
				int total = ((Mensaje)objectInputStream.readObject()).getNum();
				System.out.println("////////////////////////////////");
				System.out.println("Total recaudado hoy: "+total);
				System.out.println("////////////////////////////////");
				menu();
				break;
			case "3":
				objectOutputStream.writeObject(new Mensaje(""));
				cierre();
			default:
				System.err.println("Debes introducir el numero de la accion :/");
				menu();
		}

	}
	/**
	 * Men� que muestra los productos actuales acompa�ados de la cantidad actual
	 * Se da la opci�n de elegir que producto comprar o de volver al men� principal
	 * @param productos
	 */
	public static void menu_compra(ArrayList<Producto> productos) {

		int index = 0;
		int cantidad = 0;
		checkStock(productos);
		for (int i = 0; i < productos.size(); i++) {
			System.out.println(productos.get(i).getId() + ". " + productos.get(i).getNombre() + ", stock actual: "
					+ productos.get(i).getStock());
		}
		System.out.println("5. Volver");
		while (index <= 0 || index > productos.size()+1) {
			index = producto();
		}
		if (index == 5) {
			try {
				menu();
			} catch (ClassNotFoundException | IOException e) {
				System.err.println("Ha ocurrido un error");
			}
		}
		while(cantidad ==0){
			cantidad = cantidad();
		}
		Producto producto = productos.get(index -1);
		try {
			CompraDAO.registrarCompra(producto, cantidad);
		} catch (SQLException e) {
			// System.err.println("Error al guardar la compra");
			e.printStackTrace();
		}
	}

	/**
	 * Se solicita al usuario que introduzca el id del producto
	 * @return
	 */
	public static int producto() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Cual deseas cobrar?");
		String cantidad = sc.nextLine();
		int test;
		try {
			test = Integer.valueOf(cantidad);
		} catch (Exception e) {
			System.err.println("Debes introducir una cantidad en numeros");
			return 0;
		}
		return test;

	}
	/**
	 * Solicita al usuario que ingrese la cantidad de productos que desea comprar
	 * @return
	 */
	public static int cantidad() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Cuantos deseas cobrar?");
		String cantidad = sc.nextLine();
		int test;
		try {
			test = Integer.valueOf(cantidad);
		} catch (Exception e) {
			System.err.println("Debes introducir una cantidad en numeros");
			return 0;
		}
		return test;

	}
	/**
	 * Cierra el socket y la aplicacion
	 * @throws IOException
	 */
	public static void cierre() throws IOException {
		socket.close();
		System.err.println("Hasta la pr�xima!");
		System.exit(0);
	}
	
	/**
	 * Comprueba que el stock de los productos sea mayor que 0 y sino los repone
	 * @param productos
	 */
	public static void checkStock(ArrayList<Producto> productos) {
		
		for (int i = 0; i < productos.size(); i++) {
			Producto producto = productos.get(i);
			if(producto.getStock() <=0) {
				Mail.mandar_correo_jefe(producto);
				ProductoDAO.reponerStock(producto.getId());
				producto.setStock(ProductoDAO.defaultStock);
			}
		}
	}
}
