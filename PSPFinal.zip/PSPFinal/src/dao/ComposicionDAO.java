package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import entidades.Composicion;
/**
 * Clase que gestiona las conexiones a la base de datos para
 * la entidad composicion
 * @author alvar
 *
 */
public class ComposicionDAO {
	
    private static Connection conn = (Connection) Conexion.conectar();

    public ComposicionDAO() {}
    /**
     * Devuelve la cantidad de dinero generado en el dia actual
     * @return
     */
    public static ArrayList<Composicion> caja_del_dia() {
        Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		ArrayList<Composicion> composiciones = new ArrayList<>();
		String sql = "SELECT P.nombre as producto,SUM(C.cantidad) AS cantidad,"+
                     "P.precio_venta-P.precio_proveedor AS diferencia "+
                     "FROM composicion C "+
                     "LEFT JOIN productos P ON C.producto_id=P.id "+
                     "WHERE C.fecha LIKE \""+formatter.format(date)+
                     "\" GROUP BY C.producto_id";
		try {
			Statement stm = conn.prepareStatement(sql);
			ResultSet rs = stm.executeQuery(sql);

			while (rs.next())
				composiciones.add(new Composicion(rs.getString(1),rs.getInt(2),rs.getInt(3)));

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return composiciones;
	}

    /**
     * Registra la composicion en la base de datos
     * @param compra_id
     * @param producto_id
     * @param cantidad
     */
    public void guardarComposicion(int compra_id, int producto_id,int cantidad) {
		String sql = "insert into composicion(producto_id,compra_id,cantidad,fecha) values(?,?,?,?)";
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, producto_id);
			stmt.setInt(2, compra_id);
			stmt.setInt(3, cantidad);
			stmt.setString(4,formatter.format(date));

			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}