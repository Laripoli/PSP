package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.mysql.jdbc.Connection;

import entidades.Producto;
/**
 * Clase que gestiona las conexiones a la base de datos para
 * la entidad compras
 * @author alvar
 *
 */
public class CompraDAO {
	
	private static Connection conn = (Connection) Conexion.conectar();

	/**
	 * Registra la compra y la composici�n en la base de datos y resta el stock del producto comprado
	 * @param producto
	 * @param cantidad
	 * @throws SQLException
	 */
	public static void registrarCompra(Producto producto, int cantidad) throws SQLException {
		int compra_id = guardarCompra();
		ProductoDAO.actualizarStock(producto, cantidad);
		(new ComposicionDAO()).guardarComposicion(compra_id, producto.getId(), cantidad);
	}
	/**
	 * Registra la compra en la base de datos
	 * @return
	 * @throws SQLException
	 */
	public static int guardarCompra() throws SQLException {
		conn.createStatement();
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String sql = "insert into compra(fecha) values (\"" + formatter.format(date) + "\")";
		PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
		stmt.executeUpdate();
		ResultSet id = stmt.getGeneratedKeys();
		id.next();

		return id.getInt(1);
	}
	

}
