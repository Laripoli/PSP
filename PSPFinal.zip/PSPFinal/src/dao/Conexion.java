package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * Clase encargada de la conexion a la base de datos
 * @author alvar
 *
 */
public class Conexion {

	private static final String CONTROLADOR = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/pspFinal?useSSL=false";
	private static final String USUARIO = "root";
	private static final String CLAVE = "root";

	/**
	 * Conexion a la base de datos
	 * @return
	 */
	public static Connection conectar() {
		Connection conexion = null;

		try {
			Class.forName(CONTROLADOR);
			conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);

		} catch (ClassNotFoundException e) {
			System.err.println("Error al cargar el controlador");
			e.printStackTrace();

		} catch (SQLException e) {
			System.err.println("Error en la conexi�n, reinicia el servidor");
			System.exit(0);
		}

		return conexion;
	}
}