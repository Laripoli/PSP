package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.mysql.jdbc.Connection;

import entidades.Empleado;
/**
 * Clase que gestiona las conexiones a la base de datos para
 * la entidad empleados
 * @author alvar
 *
 */
public class EmpleadoDAO {
	private static Connection conn = (Connection) Conexion.conectar();

	/**
	 * Devuelve true si el codigo ingresado por el usuario se encuentra
	 * en la base de datos
	 * @param id
	 * @return
	 */
	public static boolean Login(String id) {
		String sql = "Select codigo from empleados";
		int codigo = Integer.valueOf(id);
		try {
			Statement stm = conn.prepareStatement(sql);
			ResultSet rs = stm.executeQuery(sql);

			while (rs.next()) {
				if (rs.getInt(1) == codigo) {
					return true;
				}
			}

		} catch (Exception e) {
			System.err.println("Ha ocurrido un error al conectar con la base de datos");

		}

		return false;
	}
	/**
	 * Genera un objeto empleado en funcion del id recibido
	 * @param info
	 * @return
	 */
	public static Empleado crearEmpleado(String info) {
		int id = Integer.valueOf(info);
		Empleado usuario = null;
		String sql = "Select * from empleados where codigo =" + id;
		try {
			Statement stm = conn.prepareStatement(sql);
			ResultSet rs = stm.executeQuery(sql);
			rs.first();
			
			
			usuario = new Empleado(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getTimestamp(6),rs.getDate(7));		

		} catch (SQLException e) {
			e.printStackTrace();
		}
		/**
		 * Actualizacion en la base de datos de la �tima conexi�n del empleado
		 */
		try {
			
			 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
			conn.createStatement();
			sql = "update empleados set ultima_sesion=? where codigo=?";
            PreparedStatement stmt = conn.prepareStatement(sql); {
                stmt.setString(1, dtf.format(now));
                stmt.setInt(2,id);
                stmt.executeUpdate();
          }
		}catch(Exception e) {
			e.printStackTrace();
		}

		return usuario;
	}
}
