package dao;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;

import entidades.Producto;
import mensaje.Mail;
/**
 * Clase que gestiona las conexiones a la base de datos para
 * la entidad productos
 * @author alvar
 *
 */
public class ProductoDAO implements Serializable {

	private static Connection conn = (Connection) Conexion.conectar();
	private ArrayList<Producto> productos;
	public final static int defaultStock = 50;

	public ProductoDAO(ArrayList<Producto> productos) {
		this.productos = productos;
	}

	public ProductoDAO() {}

	/**
	 * Devuelve un listado de todos los productos de la base de datos en
	 * forma de objeto incluyendo toda su informacion
	 * @return
	 */
	public static ArrayList<Producto> listado() {

		ArrayList<Producto> productos = new ArrayList<>();
		String sql = "Select * from productos";
		int stock = 0;
		try {
			Statement stm = conn.prepareStatement(sql);
			ResultSet rs = stm.executeQuery(sql);

			while (rs.next()) {
				stock = rs.getInt(5);
				Producto producto = new Producto(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getFloat(4), stock);
				productos.add(producto);
			}
		} catch (SQLException e) {
			System.err.println("Ha ocurrido un error con la base de datos");
		}

		return productos;
	}
	/**
	 * Se calcula el stock resultante de la compra y si es menor o igual a 0 se envia un correo al encargado
	 * y se repone.
	 * @param producto
	 * @param cantidad
	 */
	public static void actualizarStock(Producto producto, int cantidad) {

		String sql = "update productos set stock=? where id=?";
		int cantidad_final = (producto.getStock() - cantidad);
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, cantidad_final);
			stmt.setInt(2, producto.getId());
			stmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Ha ocurrido un error con la base de datos");
		}
		if(cantidad_final<=0) {
			Mail.mandar_correo_jefe(producto);
			reponerStock(producto.getId());
		}
	}
	/**
	 * Se repone el stock de un producto agotado
	 * @param id
	 */
	public static void reponerStock(int id) {
		String sql = "update productos set stock=? where id=?";
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, defaultStock);
			stmt.setInt(2, id);
			stmt.executeUpdate();
		} catch (Exception e) {
			System.err.println("Ha ocurrido un error");
		}
	}

	public ArrayList<Producto> getProductos() {
		return this.productos;
	}

}
