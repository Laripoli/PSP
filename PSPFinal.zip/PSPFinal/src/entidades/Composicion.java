package entidades;

import java.io.Serializable;
/**
 * Clase que representa la entidad composicion de la base de datos
 * @author alvar
 *
 */
public class Composicion implements Serializable{
    private String producto;
    private int diferencia;
    private int cantidad;


    public Composicion(String producto,int cantidad,int diferencia){
        this.producto=producto;
        this.cantidad=cantidad;
        this.diferencia=diferencia;
    }

    @Override
    public String toString() {
        return "Composicion [cantidad=" + cantidad + ", diferencia=" + diferencia + ", producto=" + producto + "]";
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getDiferencia() {
        return diferencia;
    }

    public void setDiferencia(int diferencia) {
        this.diferencia = diferencia;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    
}
