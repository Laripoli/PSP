package entidades;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
/**
 * Clase que representa la entidad empleados de la base de datos
 * @author alvar
 *
 */
public class Empleado implements Serializable {
	
	private int id;
	private String user;
	private String nombre;
	private String apellidos;
	private String dni;
	private Date ultima_sesion;
	private Date fecha_contratacion;


	public Empleado(String user) {
		this.user = user;
	}

	public Empleado(int id, String user, String nombre, String apellidos, String dni) {
		this.id = id;
		this.user = user;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;

	}

	public Empleado(int id, String user, String nombre, String apellidos, String dni, Date ultima_sesion,
			Date fecha_contratacion) {
		this.id = id;
		this.user = user;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
		this.ultima_sesion = ultima_sesion;
		this.fecha_contratacion = fecha_contratacion;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	@Override
	public String toString() {
		

		return "Usuario [id=" + id + ", user=" + user + ", nombre=" + nombre + ", apellidos=" + apellidos + ", dni="
				+ dni + "]";
	}

	public String bienvenida() {
		String[] trozos = String.valueOf(ultima_sesion).split(" ");
		String fecha;
		String hora;
		try {
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(trozos[0]);
			fecha = new SimpleDateFormat("dd/MM/yyyy").format(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fecha = trozos[0];
		}  
	     
		return "Bienvenido, " + nombre + " " + apellidos + ", tu �ltima conexi�n fue el "+ fecha + " a las "+ trozos[1];
	}

}
