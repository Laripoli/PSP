package entidades;

import java.io.Serializable;

/**
 * Clase que representa la entidad producto de la base de datos
 * @author alvar
 *
 */
public class Producto implements Serializable{
	private int id;
	private String nombre;
	private float precio_venta;
	private float precio_proveedor;
	private int stock;
	
	public Producto(int id, String nombre, float precio_venta, float precio_proveedor, int stock) {
		this.id = id;
		this.nombre = nombre;
		this.precio_venta = precio_venta;
		this.precio_proveedor = precio_proveedor;
		this.stock = stock;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public float getPrecio_venta() {
		return precio_venta;
	}
	public void setPrecio_venta(float precio_venta) {
		this.precio_venta = precio_venta;
	}
	public float getPrecio_proveedor() {
		return precio_proveedor;
	}
	public void setPrecio_proveedor(float precio_proveedor) {
		this.precio_proveedor = precio_proveedor;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", nombre=" + nombre + ", precio_venta=" + precio_venta + ", precio_proveedor="
				+ precio_proveedor + ", stock=" + stock + "]";
	}
	
	
}
