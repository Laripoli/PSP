package mensaje;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import dao.ProductoDAO;
import entidades.Producto;

/**
 * Clase encargada de mandar correos electronicos
 * @author alvar
 *
 */
public class Mail {
	
    final String username = "finalbosspsp@gmail.com";
    final String password = "cosillas";

    public Mail(){}

/**
 * Envia un correo al encargado informando de que se ha terminado
 * el stock de un producto y que se ha respuesto, adjuntando el precio
 * por unidad del producto faltante.
 * @param producto
 */
 public static void mandar_correo_jefe(Producto producto) {
	 
	 	System.out.println();
	 	System.out.println("Se han finalizado las existencias del producto, "+producto.getNombre());
	 	System.out.println("se enviar� un correo al encargado");
        System.out.println("Un momento..");
        final String username = "finalbosspsp@gmail.com";
        final String password = "cosillas";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
        	 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
  		   	 LocalDateTime now = LocalDateTime.now();  

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("finalbosspsp@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse("finalbosspsp@gmail.com"));
            message.setSubject("Finalizadas existencias del producto "+producto.getNombre());
            message.setText("Se han finalizado las existencias a las "+dtf.format(now)+ ", el precio por unidad es: "+producto.getPrecio_proveedor()+
            		", y se compraran "+ ProductoDAO.defaultStock +" nuevas unidades");

            Transport.send(message);
            
            System.out.println();
            

        } catch (MessagingException e) {
            System.err.println("Error al mandar correo al encargado");
        }

    }
}
