package mensaje;

import java.io.Serializable;

/**
 * Clase utilizada para mandar texto o n�meros en forma de objeto
 * @author alvar
 *
 */
public class Mensaje implements Serializable {
	private String text;
	private int num;

	public Mensaje(String text) {
		this.text = text;
	}

	public Mensaje(int num){
		this.num = num;
	}

	public String getText() {
		return text;
	}

	public int getNum(){
		return num;
	}
}
