package server;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

import dao.ComposicionDAO;
import dao.EmpleadoDAO;
import dao.ProductoDAO;
import entidades.Composicion;
import entidades.Empleado;
import entidades.Producto;
import mensaje.Mensaje;

public class Hilo extends Thread {
	private static Socket socket;

	enum Opciones {
		Mensaje, Empleado;
	}

	public Hilo(Socket inSocket) {
		socket = inSocket;
	}
	
	/**
	 * Control de envio y recibo de mensajes entre el servidor y el cliente
	 */
	public void run() {
		try {
			Socket socketActual = socket;
			System.out.println("nuevo cliente conectado!");
			// get the input stream from the connected socket
			InputStream inputStream = socketActual.getInputStream();
			// create a DataInputStream so we can read data from it.
			ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);

			OutputStream outputStream = socketActual.getOutputStream();
			// create an object output stream from the output stream so we can send an
			// object through it
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
			while (true) {
				var object = objectInputStream.readObject();
				Opciones mensaje = Opciones.valueOf(object.getClass().getSimpleName());
				Empleado usuario = null;
				switch (mensaje) {
				case Empleado:
					System.err.println("Buscando usuario");
					boolean encontrado = false;
					while (!encontrado) {
						usuario = (Empleado) object;
						if (object == null)
							usuario = (Empleado) objectInputStream.readObject();
						String info = usuario.getUser();
						if (EmpleadoDAO.Login(info)) {
							System.out.println("Login correcto");
							objectOutputStream.writeObject(EmpleadoDAO.crearEmpleado(info));
							encontrado = true;
						} else {
							System.err.println("Fallo en el login");
							objectOutputStream.writeObject(null);
							encontrado = false;
							object = null;
						}
					}
					break;
				case Mensaje:
					String accion = ((Mensaje)object).getText();
					switch(accion) {
					case "Cobrar":
						ArrayList<Producto> productos = ProductoDAO.listado();
						ProductoDAO productoDAO = new ProductoDAO(productos);
						objectOutputStream.writeObject(productoDAO);
						
						break;
					case "Caja":
						ArrayList<Composicion> cajas = ComposicionDAO.caja_del_dia();
						objectOutputStream.writeObject(new Mensaje(calculoCajaDelDia(cajas)));
						break;
					default:
						socketActual.close();
						break;
					}
				}
			}
		} catch (SocketException e) {
			System.err.println("Conexion finalizada");
		} catch (IOException e) {
			System.err.println("Ha ocurrido un error");
		} catch (ClassNotFoundException e) {
			System.err.println("Mensaje desconocido");
		}
	}

	/**
	 * Calcula la cantidad de dinero generado en el d�a actual
	 * @param cajas
	 * @return
	 */
	public static int calculoCajaDelDia(ArrayList<Composicion> cajas){
		int resultado = 0;
		for (int i=0;i<cajas.size();i++){
			resultado += (cajas.get(i).getDiferencia() * cajas.get(i).getCantidad());
		}
		return resultado;
	}

}
