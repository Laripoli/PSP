package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 * Crea 1 socket para cada cliente conectado
 * @author alvar
 *
 */
public class Server {

	private static ServerSocket ss = null;

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ss = new ServerSocket(8000);

		try {
			System.out.println("Servidor iniciado");
			while (true) {
				Socket socket = ss.accept();
				Hilo hilo = new Hilo(socket);
				hilo.start();
			}
		} catch (Exception e) {
			System.err.println("Ha ocurrido un error");
		}
		ss.close();
	}

}
