-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.7.24 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para pspFinal
DROP DATABASE IF EXISTS `pspFinal`;
CREATE DATABASE IF NOT EXISTS `pspFinal` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pspFinal`;

-- Volcando estructura para tabla pspFinal.composicion
DROP TABLE IF EXISTS `composicion`;
CREATE TABLE IF NOT EXISTS `composicion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) DEFAULT NULL,
  `compra_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `compra_id` (`compra_id`),
  CONSTRAINT `FK_composicion_compra` FOREIGN KEY (`compra_id`) REFERENCES `compra` (`id`),
  CONSTRAINT `FK_composicion_productos` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla pspFinal.composicion: ~48 rows (aproximadamente)
DELETE FROM `composicion`;
/*!40000 ALTER TABLE `composicion` DISABLE KEYS */;
INSERT INTO `composicion` (`id`, `producto_id`, `compra_id`, `cantidad`, `fecha`) VALUES
	(12, 1, 34, 2, '2021-02-19'),
	(13, 3, 35, 1, '2021-02-19'),
	(14, 2, 36, 1, '2021-02-19'),
	(15, 3, 37, 4, '2021-02-19'),
	(16, 1, 47, 1, '2021-02-24'),
	(17, 3, 52, 1, '2021-02-24'),
	(18, 1, 53, 25, '2021-02-24'),
	(19, 4, 54, 39, '2021-02-24'),
	(20, 1, 55, 1, '2021-02-24'),
	(21, 1, 56, 1, '2021-02-24'),
	(22, 1, 57, 1, '2021-02-24'),
	(23, 3, 58, 1, '2021-02-24'),
	(24, 3, 59, 1, '2021-02-24'),
	(25, 4, 60, 1, '2021-02-24'),
	(26, 2, 61, 96, '2021-02-24'),
	(27, 4, 62, 1, '2021-02-24'),
	(28, 1, 64, 1, '2021-02-24'),
	(29, 1, 66, 1, '2021-02-24'),
	(30, 1, 67, 1, '2021-02-24'),
	(31, 2, 68, 1, '2021-02-24'),
	(32, 1, 69, 1, '2021-02-24'),
	(33, 2, 70, 1, '2021-02-24'),
	(34, 1, 71, 1, '2021-02-24'),
	(35, 1, 72, 1, '2021-02-24'),
	(36, 1, 73, 25, '2021-02-24'),
	(37, 2, 74, 1, '2021-02-24'),
	(38, 3, 75, 1, '2021-02-24'),
	(39, 1, 76, 25, '2021-02-24'),
	(40, 2, 77, 1, '2021-02-24'),
	(41, 1, 78, 4, '2021-02-24'),
	(42, 4, 79, 1, '2021-02-24'),
	(43, 1, 80, 1, '2021-02-24'),
	(44, 1, 81, 1, '2021-02-24'),
	(45, 1, 82, 19, '2021-02-24'),
	(46, 1, 83, 50, '2021-02-24'),
	(47, 1, 84, 50, '2021-02-24'),
	(48, 1, 85, 52, '2021-02-24'),
	(49, 3, 86, 30, '2021-02-24'),
	(50, 2, 87, 15, '2021-02-24'),
	(51, 4, 88, 356, '2021-02-24'),
	(52, 1, 89, 3, '2021-02-24'),
	(53, 3, 90, 20, '2021-02-24'),
	(54, 2, 91, 30, '2021-02-24'),
	(55, 1, 92, 20, '2021-02-24'),
	(56, 1, 93, 30, '2021-02-24'),
	(57, 2, 94, 20, '2021-02-24'),
	(58, 3, 95, 5, '2021-02-24'),
	(59, 4, 96, 13, '2021-02-24');
/*!40000 ALTER TABLE `composicion` ENABLE KEYS */;

-- Volcando estructura para tabla pspFinal.compra
DROP TABLE IF EXISTS `compra`;
CREATE TABLE IF NOT EXISTS `compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla pspFinal.compra: ~94 rows (aproximadamente)
DELETE FROM `compra`;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
INSERT INTO `compra` (`id`, `fecha`) VALUES
	(3, '2021-02-17'),
	(4, '2021-02-17'),
	(5, '2021-02-17'),
	(6, '2021-02-17'),
	(7, '2021-02-17'),
	(8, '2021-02-19'),
	(9, '2021-02-19'),
	(10, '2021-02-19'),
	(11, '2021-02-19'),
	(12, '2021-02-19'),
	(13, '2021-02-19'),
	(14, '2021-02-19'),
	(15, '2021-02-19'),
	(16, '2021-02-19'),
	(17, '2021-02-19'),
	(18, '2021-02-19'),
	(19, '2021-02-19'),
	(20, '2021-02-19'),
	(21, '2021-02-19'),
	(22, '2021-02-19'),
	(23, '2021-02-19'),
	(24, '2021-02-19'),
	(25, '2021-02-19'),
	(26, '2021-02-19'),
	(27, '2021-02-19'),
	(28, '2021-02-19'),
	(29, '2021-02-19'),
	(30, '2021-02-19'),
	(31, '2021-02-19'),
	(32, '2021-02-19'),
	(33, '2021-02-19'),
	(34, '2021-02-19'),
	(35, '2021-02-19'),
	(36, '2021-02-19'),
	(37, '2021-02-19'),
	(38, '2021-02-20'),
	(39, '2021-02-20'),
	(40, '2021-02-20'),
	(41, '2021-02-20'),
	(42, '2021-02-20'),
	(43, '2021-02-20'),
	(44, '2021-02-20'),
	(45, '2021-02-20'),
	(46, '2021-02-20'),
	(47, '2021-02-24'),
	(48, '2021-02-24'),
	(49, '2021-02-24'),
	(50, '2021-02-24'),
	(51, '2021-02-24'),
	(52, '2021-02-24'),
	(53, '2021-02-24'),
	(54, '2021-02-24'),
	(55, '2021-02-24'),
	(56, '2021-02-24'),
	(57, '2021-02-24'),
	(58, '2021-02-24'),
	(59, '2021-02-24'),
	(60, '2021-02-24'),
	(61, '2021-02-24'),
	(62, '2021-02-24'),
	(63, '2021-02-24'),
	(64, '2021-02-24'),
	(65, '2021-02-24'),
	(66, '2021-02-24'),
	(67, '2021-02-24'),
	(68, '2021-02-24'),
	(69, '2021-02-24'),
	(70, '2021-02-24'),
	(71, '2021-02-24'),
	(72, '2021-02-24'),
	(73, '2021-02-24'),
	(74, '2021-02-24'),
	(75, '2021-02-24'),
	(76, '2021-02-24'),
	(77, '2021-02-24'),
	(78, '2021-02-24'),
	(79, '2021-02-24'),
	(80, '2021-02-24'),
	(81, '2021-02-24'),
	(82, '2021-02-24'),
	(83, '2021-02-24'),
	(84, '2021-02-24'),
	(85, '2021-02-24'),
	(86, '2021-02-24'),
	(87, '2021-02-24'),
	(88, '2021-02-24'),
	(89, '2021-02-24'),
	(90, '2021-02-24'),
	(91, '2021-02-24'),
	(92, '2021-02-24'),
	(93, '2021-02-24'),
	(94, '2021-02-24'),
	(95, '2021-02-24'),
	(96, '2021-02-24');
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;

-- Volcando estructura para tabla pspFinal.empleados
DROP TABLE IF EXISTS `empleados`;
CREATE TABLE IF NOT EXISTS `empleados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL DEFAULT '0',
  `nombre` varchar(50) DEFAULT NULL,
  `apellidos` varchar(50) DEFAULT NULL,
  `dni` varchar(50) DEFAULT NULL,
  `ultima_sesion` datetime DEFAULT NULL,
  `fecha_contratacion` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla pspFinal.empleados: ~0 rows (aproximadamente)
DELETE FROM `empleados`;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` (`id`, `codigo`, `nombre`, `apellidos`, `dni`, `ultima_sesion`, `fecha_contratacion`) VALUES
	(1, 1234, 'Alvaro', 'Lara Cazorla', '26261545F', '2021-02-24 21:17:27', '2021-02-17');
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;

-- Volcando estructura para tabla pspFinal.productos
DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `precio_venta` float DEFAULT NULL,
  `precio_proveedor` float DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla pspFinal.productos: ~4 rows (aproximadamente)
DELETE FROM `productos`;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` (`id`, `nombre`, `precio_venta`, `precio_proveedor`, `stock`) VALUES
	(1, 'Disco duro', 50, 20, 20),
	(2, 'USB', 10, 2, 30),
	(3, 'Monitor', 125, 60, 45),
	(4, 'Ratón', 70, 20, 37);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
